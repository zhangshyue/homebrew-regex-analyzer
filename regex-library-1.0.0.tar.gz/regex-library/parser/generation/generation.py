# Internal imports
from extraction.extraction import FoundExpression


def generate(parsed_expression, exp: FoundExpression):
    # Write the actual data out to a PB message
    pass