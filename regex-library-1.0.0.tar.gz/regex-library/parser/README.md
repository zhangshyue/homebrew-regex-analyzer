# Parser

The parsing library that generates protobuf types for all the regular expressions it can find in a supplied directory

## Usage
``