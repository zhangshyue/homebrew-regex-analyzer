import re
import unrelated

exp = re.compile(r"{.*}")
