let x = /(.*)/;
let y = new RegExp("\w+");
y.test("hello");