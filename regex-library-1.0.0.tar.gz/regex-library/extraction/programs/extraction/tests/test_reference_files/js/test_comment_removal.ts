/**
 * Opening comments
 */
console.log("Hello, world!");// Comment
// Comment