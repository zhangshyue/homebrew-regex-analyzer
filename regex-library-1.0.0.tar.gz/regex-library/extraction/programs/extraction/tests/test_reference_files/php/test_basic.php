<?php
$str = "Test";
echo preg_match("/\d+/", $str);
?>