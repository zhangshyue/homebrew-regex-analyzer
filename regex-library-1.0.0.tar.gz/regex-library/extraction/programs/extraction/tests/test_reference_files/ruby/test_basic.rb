def test
    /test+/.match("test")
end

test
