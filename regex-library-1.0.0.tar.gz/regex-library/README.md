# Regex Library

The integrated library combining all the separate components of the RegEx comps project

# Installation
Install [Rust](https://rustup.rs/) and [Python 3](https://www.python.org/downloads/)

Run `make install`

# Usage
`python3 main.py [ENTRYPOINT]` where the entrypoint is either a directory or a file